from env_MAB import *


def random_argmax(a):
    """
    Select the index corresponding to the maximum in the input list.
    Ties are randomly broken.
    """
    return np.random.choice(np.where(a == a.max())[0])


class Explore:
    def __init__(self, MAB):
        self.MAB = MAB

    def reset(self):
        self.MAB.reset()

    def play_one_step(self):
        pass


class Greedy:
    def __init__(self, MAB):
        self.MAB = MAB

    def reset(self):
        self.MAB.reset()

    def play_one_step(self):
        pass


class ETC:
    def __init__(self, MAB, delta=0.05):
        self.MAB = MAB

    def reset(self):
        self.MAB.reset()

    def play_one_step(self):
        pass


class Epgreedy:
    def __init__(self, MAB, delta=0.05):
        self.MAB = MAB

    def reset(self):
        self.MAB.reset()

    def play_one_step(self):
        pass


class UCB:
    def __init__(self, MAB, delta=0.05):
        self.MAB = MAB

    def reset(self):
        """
        Reset the instance and eliminate history.
        """
        self.MAB.reset()

    def play_one_step(self):
        pass


class Thompson_sampling:
    def __init__(self, MAB):
        self.MAB = MAB

    def reset(self):
        """
        Reset the instance and eliminate history.
        """
        self.MAB.reset()

    def play_one_step(self):
        """
        Implement one step of the Thompson sampling algorithm.
        """
        pass
